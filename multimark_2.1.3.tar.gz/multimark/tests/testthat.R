library(testthat)
library(multimark)

test_check("multimark")
